@echo off
cd /d "%~dp0"
start "" /b "EnvChecker.exe"
exit
